# version 0.3.1

- added calibration for `predict` and `simulate` methods for `regressor` objects
- added `get_model_list` function giving the list of models available
- add simulation and prediction for non-calibrated models

# version 0.2.0

- list of models with `get_model_list`