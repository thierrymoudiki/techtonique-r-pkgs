.onLoad <- function(libname, pkgname) {
  if (!requireNamespace("reticulate", quietly = TRUE)) {
    stop("Package 'reticulate' is required. Please install it with install.packages('reticulate').", call. = FALSE)
  }
  
  # Get Python configuration
  py_config <- tryCatch({
    reticulate::py_config()
  }, error = function(e) NULL)
  
  # Detect if 'r-reticulate' exists
  env_exists <- "r-reticulate" %in% reticulate::conda_list()$name
  
  if (!env_exists) {
    message("Conda environment 'r-reticulate' not found. Creating it...")
    tryCatch({
      reticulate::conda_create("r-reticulate")
    }, error = function(e) {
      stop("Failed to create 'r-reticulate' environment. Please check your Conda installation.", call. = FALSE)
    })
  }
  
  # Try importing the package
  tml <- tryCatch({
    reticulate::import("tisthemachinelearner", delay_load = TRUE)
  }, error = function(e) {
    message("Python package 'tisthemachinelearner' not found. Installing via pip...")
    
    # Install in the correct Python environment
    tryCatch({
      reticulate::py_install("git+https://github.com/Techtonique/tisthemachinelearner.git", 
                             envname = "r-reticulate", 
                             method = "auto")
      
      # Try importing again after installation
      reticulate::import("tisthemachinelearner")
      
    }, error = function(e2) {
      stop("Failed to install or import 'tisthemachinelearner'. Please install it manually with:\n
            reticulate::py_install('git+https://github.com/Techtonique/tisthemachinelearner.git', 
                                   envname = 'r-reticulate', method = 'auto')", call. = FALSE)
    })
  })
  
  assign("tisthemachinelearner", tml)  # Store in package namespace
}
