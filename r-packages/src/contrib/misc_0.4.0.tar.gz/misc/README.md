# misc

[![misc status badge](https://techtonique.r-universe.dev/badges/misc)](https://techtonique.r-universe.dev/misc) [![Documentation](https://img.shields.io/badge/documentation-is_here-green)](https://techtonique.github.io/misc/index.html)

## Description

An R package containing powerful functions that I use frequently.

Read the [vignettes](https://techtonique.github.io/misc/) ("Articles") for more details.

## Installation

```r
remotes::install_github("thierrymoudiki/misc")
```

Or from R-universe.

