## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(echo = TRUE)

## -----------------------------------------------------------------------------
library(ForecastComb)

## -----------------------------------------------------------------------------
data(electricity)

print(head(electricity))

(forecasting_methods <- colnames(electricity)[1:5])

train_obs <- electricity[1:84, "Actual"]
train_pred <- electricity[1:84, forecasting_methods]
test_obs <- electricity[85:123, "Actual"]
test_pred <- electricity[85:123, forecasting_methods]

## -----------------------------------------------------------------------------
data <- ForecastComb::foreccomb(train_obs, train_pred, test_obs, test_pred)

## -----------------------------------------------------------------------------
start <- proc.time()[3]
obj <- ahead::comb_OLS(data)
print(proc.time()[3] - start)

print(class(obj))

print(obj$Accuracy_Test)

print(obj$Weights)

# check
print(mean(predict(obj, test_pred) - test_obs))

## ----fig.width=7.5, eval=FALSE------------------------------------------------
# plot(obj)

## ----eval=TRUE----------------------------------------------------------------
start <- proc.time()[3]
obj <- ahead::comb_Ridge(data)
print(proc.time()[3] - start)

## ----eval=TRUE----------------------------------------------------------------

print(obj$Weights)

print(class(obj))

print(obj$Accuracy_Test)

# check 
print(mean(predict(obj, test_pred) - test_obs))

## ----fig.width=7.5, eval=FALSE------------------------------------------------
# plot(obj)

