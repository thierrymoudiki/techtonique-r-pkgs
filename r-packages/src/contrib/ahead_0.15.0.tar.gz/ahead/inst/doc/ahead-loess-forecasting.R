## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----include=FALSE------------------------------------------------------------
library(ahead)
library(fpp)
library(datasets)
library(randomForest)
library(e1071)

## ----"bootstrap-mean", fig.width=7.2------------------------------------------
plot(loessf(Nile, h=20, 
            type_pi = "bootstrap",
            type_aggregation = "mean",
            level=95, B=10))

## ----"bootstrap-median", fig.width=7.2----------------------------------------
plot(loessf(Nile, h=20, 
            type_pi = "bootstrap",
            type_aggregation = "median",
            level=95, B=10))

## ----"blockbootstrap-mean", fig.width=7.2-------------------------------------
plot(loessf(Nile, h=20, 
            type_pi = "blockbootstrap",
            type_aggregation = "mean",
            level=95, B=10))

## ----"blockbootstrap-median", fig.width=7.2-----------------------------------
plot(loessf(Nile, h=20, 
            type_pi = "blockbootstrap",
            type_aggregation = "median",
            level=95, B=10))

