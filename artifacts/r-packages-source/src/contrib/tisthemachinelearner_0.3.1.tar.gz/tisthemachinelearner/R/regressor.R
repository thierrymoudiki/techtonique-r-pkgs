#' Create a regression model using tisthemachinelearner
#' 
#' @param x Feature matrix
#' @param y Target vector
#' @param model_name Name of the sklearn model to use
#' @param calibration Logical flag to indicate if calibration of residuals should be used
#' @param seed Seed for the random number generator
#' @param ... Additional parameters passed to the sklearn model
#' @return A regressor object
#' @export
#' @examples
#' # Split features and target
#' X <- as.matrix(mtcars[, -1])  # all columns except mpg
#' y <- mtcars[, 1]              # mpg column
#' 
#' # Create train/test split
#' set.seed(42)
#' train_idx <- sample(nrow(mtcars), size = floor(0.8 * nrow(mtcars)))
#' X_train <- X[train_idx, ]
#' X_test <- X[-train_idx, ]
#' y_train <- y[train_idx]
#' y_test <- y[-train_idx]
#' 
#' # Fit linear regression model
#' reg_linear <- regressor(X_train, y_train, "LinearRegression")
#' 
#' # Make predictions
#' predictions <- predict(reg_linear, X_test)
#' 
#' # Calculate RMSE
#' (rmse <- sqrt(mean((predictions - y_test)^2)))
#' 
regressor <- function(x, y, model_name, calibration = FALSE,
seed = 42, ...) {
  # Import tisthemachinelearner
  tml <- reticulate::import("tisthemachinelearner")
  
  # Create model instance
  model <- tml$Regressor(model_name, ...)

  # Convert inputs to numpy arrays
  np <- reticulate::import("numpy")
  x_array <- np$array(x)
  y_array <- np$array(y)
  
  if (calibration == FALSE) {    
    # Fit the model
    model$fit(x_array, y_array)
    residuals <- as.vector(y_array - model$predict(x_array))
    # Return the fitted model
    structure(
      list(
        model = model,
        residuals = residuals,
        df.residual = length(y_array) - ncol(x_array) - 1
      ),
      class = "regressor"
    )
} else {
  # split the data into training and calibration set
  set.seed(seed)
  train_idx <- sample(nrow(x), size = floor(0.5 * nrow(x)))
  x_train <- np$array(x[train_idx, ])
  x_cal <- np$array(x[-train_idx, ])
  y_train <- np$array(y[train_idx])
  y_cal <- np$array(y[-train_idx])
  
  # fit the model
  model$fit(x_train, y_train)
  
  # predict the calibration set
  y_cal_pred <- as.vector(model$predict(x_cal))
  
  # obtain residuals on calibration set
  calib_residuals <- as.vector(y_cal - y_cal_pred)
  
  # fit model on calibration set
  model$fit(x_cal, y_cal)  
  
  # return the fitted model
  structure(
    list(
      model = model,
      residuals = calib_residuals,
      df.residual = length(y_cal) - ncol(x_cal) - 1
    ),
    class = "regressor"
  )
}
}

#' @export
predict.regressor <- function(object, newdata, nsim = 250L, level = 95,
                                method = c("none", "splitconformal", "surrogate", 
                                "bootstrap", "tsbootstrap"),
                                seed = 123, ...) {

  method <- match.arg(method)
  np <- reticulate::import("numpy")
  x_array <- np$array(newdata)
  pred <- as.vector(object$model$predict(x_array))

  if (method == "none") {

    return(pred)

  } else {

    if (method == "gaussian") {         
      # Get the residual standard error from the model
      sigma <- try(sqrt(sum(object$residuals^2) / object$model$df.residual), silent=TRUE)
      # Generate random normal errors
      errors <- matrix(rnorm(length(pred) * nsim, 
                            mean = 0, 
                            sd = sigma), 
                      nrow = length(pred), 
                      ncol = nsim)
    }
  
    if (method == "surrogate") {
      errors <- tseries::surrogate(sample(object$residuals, size=length(pred), replace=TRUE), ns=nsim)
    }

    if (method == "bootstrap") {
      errors <- matrix(sample(object$residuals, size=length(pred)*nsim, replace=TRUE), 
      nrow=length(pred), ncol=nsim)    
    }

    if (method == "tsbootstrap") {
      errors <- tseries::tsbootstrap(sample(object$residuals, size=length(pred), replace=TRUE), 
      type="block", nb=nsim)
    }

    if (method != "splitconformal")
    {
      # Generate simulations
      sims <- simulate.regressor(object, newdata = newdata, nsim = nsim, 
                                  method = method, seed = seed)            
      # Calculate prediction intervals using empirical quantiles
      alpha <- (1 - level/100) / 2
      pred <- apply(sims, 1, median)
      lower <- apply(sims, 1, quantile, probs = alpha)
      upper <- apply(sims, 1, quantile, probs = 1 - alpha)            
      # Return as matrix with columns fit, lwr, upr
      return(cbind(fit = drop(pred), 
                  lwr = lower,
                  upr = upper))
    } else {
      multiplier <- quantile(abs(object$residuals), probs = level/100)
      pred <- drop(pred)
      lower <- pred - multiplier
      upper <- pred + multiplier
      return(cbind(fit = drop(pred), 
                  lwr = lower,
                  upr = upper))
    }      
    
  }
}

#' @export
simulate.regressor <- function(object, newdata, nsim = 250L, level = 95,
                                method = c("surrogate", "bootstrap", "tsbootstrap"),
                                seed = 123, ...) {
  set.seed(seed)  
  method <- match.arg(method)  
  np <- reticulate::import("numpy")
  pred <- as.vector(object$model$predict(np$array(newdata)))
  
  if (method == "surrogate") {
    errors <- tseries::surrogate(sample(object$residuals, size=length(pred), replace=TRUE), ns=nsim)
  }
  
  if (method == "bootstrap") {
    errors <- matrix(sample(object$residuals, size=length(pred)*nsim, replace=TRUE), nrow=length(pred), ncol=nsim)    
  }
  
  if (method == "tsbootstrap") {
    errors <- tseries::tsbootstrap(sample(object$residuals, size=length(pred), replace=TRUE), type="block", nb=nsim)
  }
  # Add errors to fitted values to create simulations  
  result <- errors + drop(pred)
  
  # Convert to data.frame to match simulate.lm output format
  result <- as.data.frame(result)
  colnames(result) <- paste0("sim_", 1:nsim)
  return(result)
}

