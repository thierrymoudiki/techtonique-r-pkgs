library(testthat)
library(ahead)

test_check("ahead")
