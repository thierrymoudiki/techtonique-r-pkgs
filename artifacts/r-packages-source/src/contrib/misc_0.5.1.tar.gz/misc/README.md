# misc

[![misc status badge](https://r-packages.techtonique.net/badges/misc)](https://r-packages.techtonique.net/misc) [![Documentation](https://img.shields.io/badge/documentation-is_here-green)](https://techtonique.github.io/misc/index.html)

## Description

An R package containing powerful functions that I use frequently.

Read the [vignettes](https://techtonique.github.io/misc/) ("Articles") for more details.

## Installation

```R
options(repos = c(techtonique = "https://r-packages.techtonique.net",
                  CRAN = "https://cloud.r-project.org"))

install.packages("misc")
```

