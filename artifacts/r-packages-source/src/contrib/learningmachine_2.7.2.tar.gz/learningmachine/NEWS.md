# version 2.6.0 (2024-11-08)

- conformal confidence intervals for average effects
- use Wilcoxon signed-rank test for nonparametric test on average effects

# version 2.5.0 (2024-09-20)

- tests for nonparametric confidence intervals of average effects (based on rescaled winkler scores)

# version 2.4.0 (2024-08-29)

- add bootstrapped confidence intervals for average effects

# version 2.3.0 (2024-08-27)

- add nonparametric confidence intervals for average effects

# version 2.2.2 (2024-08-18)

- Include Random Vector Functional Link Networks
- Add online learning 
- Read: https://thierrymoudiki.github.io/blog/2024/08/19/r/python/code-conformal-adaptive-RVFL