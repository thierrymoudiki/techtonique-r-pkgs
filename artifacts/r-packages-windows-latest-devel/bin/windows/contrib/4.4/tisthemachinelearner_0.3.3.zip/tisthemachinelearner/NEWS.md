# version 0.3.2

- added calibration for `predict` and `simulate` methods for `regressor` objects
- added `get_model_list` function giving the list of models available
- add simulation and prediction for non-calibrated models
- align with Python version 

# version 0.2.0

- list of models with `get_model_list`